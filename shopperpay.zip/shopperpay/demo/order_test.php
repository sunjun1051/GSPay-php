<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Document</title>
</head>

<form action="../index.php" method="post">
<dl>
<dd><input type="text" name="merOrdId" value="2016081210344489"></dd>
</dl>
<dl>
<dd><input type="text" name="productName[]" value="Anti Aging Eye Cream"></dd>
<dd><input type="text" name="productAttr[]" value=""></dd>
<dd><input type="text" name="imageUrl[]" value=""></dd>
<dd><input type="text" name="categoryName[]" value=""></dd>
<dd><input type="text" name="perPrice[]" value="240.00"></dd>
<dd><input type="text" name="curyId[]" value="USD"></dd>
<dd><input type="text" name="quantity[]" value="1"></dd>
<dd><input type="text" name="perWeight[]" value="0.5"></dd>
<dd><input type="text" name="perVolume[]" value="300"></dd>
<dd><input type="text" name="perTotalAmt[]" value="240.00"></dd>
<dd><input type="text" name="filingNumber[]" value="123456789000"></dd>
<dd><input type="text" name="SKU[]" value="123456789000"></dd>
</dl>
<!--  
<dl>
<dd><input type="text" name="productName[]" value="2"></dd>
<dd><input type="text" name="productAttr[]" value="2"></dd>
<dd><input type="text" name="imageUrl[]" value="2"></dd>
<dd><input type="text" name="categoryName[]" value="2"></dd>
<dd><input type="text" name="perPrice[]" value="2"></dd>
<dd><input type="text" name="curyId[]" value="2"></dd>
<dd><input type="text" name="quantity[]" value="2"></dd>
<dd><input type="text" name="perWeight[]" value="2"></dd>
<dd><input type="text" name="perVolume[]" value="2"></dd>
<dd><input type="text" name="perTotalAmt[]" value="2"></dd>
<dd><input type="text" name="filingNumber[]" value="2"></dd>
<dd><input type="text" name="SKU[]" value="2"></dd>
</dl>
-->
<dl>
<dd><input type="text" name="proTotalAmt" value="240"></dd>
</dl>

<input type="submit" name="china_pay" value="submit">
</form>

<body>

</body>
</html>
<?php
echo json_encode(array('isSuccess' => '1'));